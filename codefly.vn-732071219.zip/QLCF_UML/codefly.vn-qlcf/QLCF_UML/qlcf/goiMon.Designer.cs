﻿namespace qlcf
{
    partial class goiMon
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(goiMon));
            this.thongTinBan = new System.Windows.Forms.GroupBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.btnBan6 = new System.Windows.Forms.Button();
            this.btnBan3 = new System.Windows.Forms.Button();
            this.btnBan5 = new System.Windows.Forms.Button();
            this.btnBan2 = new System.Windows.Forms.Button();
            this.btnBan4 = new System.Windows.Forms.Button();
            this.btnBan1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.mDanhMuc = new System.Windows.Forms.ToolStripMenuItem();
            this.mBan = new System.Windows.Forms.ToolStripMenuItem();
            this.mThucDon = new System.Windows.Forms.ToolStripMenuItem();
            this.mHoaDon = new System.Windows.Forms.ToolStripMenuItem();
            this.mThoat = new System.Windows.Forms.ToolStripMenuItem();
            this.trợGiúpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mTacGia = new System.Windows.Forms.ToolStripMenuItem();
            this.mUpdate = new System.Windows.Forms.ToolStripMenuItem();
            this.mNhanVien = new System.Windows.Forms.ToolStripMenuItem();
            this.thongTinBan.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // thongTinBan
            // 
            this.thongTinBan.Controls.Add(this.checkBox6);
            this.thongTinBan.Controls.Add(this.checkBox3);
            this.thongTinBan.Controls.Add(this.checkBox5);
            this.thongTinBan.Controls.Add(this.checkBox2);
            this.thongTinBan.Controls.Add(this.checkBox4);
            this.thongTinBan.Controls.Add(this.checkBox1);
            this.thongTinBan.Controls.Add(this.btnBan6);
            this.thongTinBan.Controls.Add(this.btnBan3);
            this.thongTinBan.Controls.Add(this.btnBan5);
            this.thongTinBan.Controls.Add(this.btnBan2);
            this.thongTinBan.Controls.Add(this.btnBan4);
            this.thongTinBan.Controls.Add(this.btnBan1);
            this.thongTinBan.Location = new System.Drawing.Point(42, 66);
            this.thongTinBan.Name = "thongTinBan";
            this.thongTinBan.Size = new System.Drawing.Size(579, 243);
            this.thongTinBan.TabIndex = 1;
            this.thongTinBan.TabStop = false;
            this.thongTinBan.Text = "Trạng thái bàn";
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.ForeColor = System.Drawing.Color.Green;
            this.checkBox6.Location = new System.Drawing.Point(420, 196);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(72, 17);
            this.checkBox6.TabIndex = 1;
            this.checkBox6.Text = "Còn trống";
            this.checkBox6.UseVisualStyleBackColor = true;
            this.checkBox6.CheckedChanged += new System.EventHandler(this.checkBox6_CheckedChanged);
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.ForeColor = System.Drawing.Color.Green;
            this.checkBox3.Location = new System.Drawing.Point(123, 192);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(72, 17);
            this.checkBox3.TabIndex = 1;
            this.checkBox3.Text = "Còn trống";
            this.checkBox3.UseVisualStyleBackColor = true;
            this.checkBox3.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.ForeColor = System.Drawing.Color.Green;
            this.checkBox5.Location = new System.Drawing.Point(420, 129);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(72, 17);
            this.checkBox5.TabIndex = 1;
            this.checkBox5.Text = "Còn trống";
            this.checkBox5.UseVisualStyleBackColor = true;
            this.checkBox5.CheckedChanged += new System.EventHandler(this.checkBox5_CheckedChanged);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.ForeColor = System.Drawing.Color.Green;
            this.checkBox2.Location = new System.Drawing.Point(123, 125);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(72, 17);
            this.checkBox2.TabIndex = 1;
            this.checkBox2.Text = "Còn trống";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.ForeColor = System.Drawing.Color.Green;
            this.checkBox4.Location = new System.Drawing.Point(420, 62);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(72, 17);
            this.checkBox4.TabIndex = 1;
            this.checkBox4.Text = "Còn trống";
            this.checkBox4.UseVisualStyleBackColor = true;
            this.checkBox4.CheckedChanged += new System.EventHandler(this.checkBox4_CheckedChanged);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.ForeColor = System.Drawing.Color.Green;
            this.checkBox1.Location = new System.Drawing.Point(123, 58);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(72, 17);
            this.checkBox1.TabIndex = 1;
            this.checkBox1.Text = "Còn trống";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // btnBan6
            // 
            this.btnBan6.Enabled = false;
            this.btnBan6.Location = new System.Drawing.Point(339, 192);
            this.btnBan6.Name = "btnBan6";
            this.btnBan6.Size = new System.Drawing.Size(75, 23);
            this.btnBan6.TabIndex = 0;
            this.btnBan6.Text = "Bàn 6";
            this.btnBan6.UseVisualStyleBackColor = true;
            this.btnBan6.Click += new System.EventHandler(this.btnBan6_Click);
            // 
            // btnBan3
            // 
            this.btnBan3.Enabled = false;
            this.btnBan3.Location = new System.Drawing.Point(42, 188);
            this.btnBan3.Name = "btnBan3";
            this.btnBan3.Size = new System.Drawing.Size(75, 23);
            this.btnBan3.TabIndex = 0;
            this.btnBan3.Text = "Bàn 3";
            this.btnBan3.UseVisualStyleBackColor = true;
            this.btnBan3.Click += new System.EventHandler(this.btnBan3_Click);
            // 
            // btnBan5
            // 
            this.btnBan5.Enabled = false;
            this.btnBan5.Location = new System.Drawing.Point(339, 125);
            this.btnBan5.Name = "btnBan5";
            this.btnBan5.Size = new System.Drawing.Size(75, 23);
            this.btnBan5.TabIndex = 0;
            this.btnBan5.Text = "Bàn 5";
            this.btnBan5.UseVisualStyleBackColor = true;
            this.btnBan5.Click += new System.EventHandler(this.btnBan5_Click);
            // 
            // btnBan2
            // 
            this.btnBan2.Enabled = false;
            this.btnBan2.Location = new System.Drawing.Point(42, 121);
            this.btnBan2.Name = "btnBan2";
            this.btnBan2.Size = new System.Drawing.Size(75, 23);
            this.btnBan2.TabIndex = 0;
            this.btnBan2.Text = "Bàn 2";
            this.btnBan2.UseVisualStyleBackColor = true;
            this.btnBan2.Click += new System.EventHandler(this.btnBan2_Click);
            // 
            // btnBan4
            // 
            this.btnBan4.Enabled = false;
            this.btnBan4.Location = new System.Drawing.Point(339, 58);
            this.btnBan4.Name = "btnBan4";
            this.btnBan4.Size = new System.Drawing.Size(75, 23);
            this.btnBan4.TabIndex = 0;
            this.btnBan4.Text = "Bàn 4";
            this.btnBan4.UseVisualStyleBackColor = true;
            this.btnBan4.Click += new System.EventHandler(this.btnBan4_Click);
            // 
            // btnBan1
            // 
            this.btnBan1.Enabled = false;
            this.btnBan1.Location = new System.Drawing.Point(42, 54);
            this.btnBan1.Name = "btnBan1";
            this.btnBan1.Size = new System.Drawing.Size(75, 23);
            this.btnBan1.TabIndex = 0;
            this.btnBan1.Text = "Bàn 1";
            this.btnBan1.UseVisualStyleBackColor = true;
            this.btnBan1.Click += new System.EventHandler(this.btnBan1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label2.Location = new System.Drawing.Point(483, 358);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(177, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Chọn một bàn còn trống để gọi món";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mDanhMuc,
            this.trợGiúpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(672, 24);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // mDanhMuc
            // 
            this.mDanhMuc.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mBan,
            this.mThucDon,
            this.mHoaDon,
            this.mNhanVien,
            this.mThoat});
            this.mDanhMuc.Image = global::qlcf.Properties.Resources.menu_tan_icon;
            this.mDanhMuc.Name = "mDanhMuc";
            this.mDanhMuc.Size = new System.Drawing.Size(90, 20);
            this.mDanhMuc.Text = "Danh mục";
            // 
            // mBan
            // 
            this.mBan.Name = "mBan";
            this.mBan.Size = new System.Drawing.Size(170, 22);
            this.mBan.Text = "Quản lý bàn";
            this.mBan.Click += new System.EventHandler(this.mBan_Click);
            // 
            // mThucDon
            // 
            this.mThucDon.Name = "mThucDon";
            this.mThucDon.Size = new System.Drawing.Size(170, 22);
            this.mThucDon.Text = "Quản lý thực đơn";
            this.mThucDon.Click += new System.EventHandler(this.mThucDon_Click);
            // 
            // mHoaDon
            // 
            this.mHoaDon.Name = "mHoaDon";
            this.mHoaDon.Size = new System.Drawing.Size(170, 22);
            this.mHoaDon.Text = "Quản lý hóa đơn";
            this.mHoaDon.Click += new System.EventHandler(this.mHoaDon_Click);
            // 
            // mThoat
            // 
            this.mThoat.Name = "mThoat";
            this.mThoat.Size = new System.Drawing.Size(170, 22);
            this.mThoat.Text = "Thoát";
            this.mThoat.Click += new System.EventHandler(this.mThoat_Click);
            // 
            // trợGiúpToolStripMenuItem
            // 
            this.trợGiúpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mTacGia,
            this.mUpdate});
            this.trợGiúpToolStripMenuItem.Image = global::qlcf.Properties.Resources.tan_info;
            this.trợGiúpToolStripMenuItem.Name = "trợGiúpToolStripMenuItem";
            this.trợGiúpToolStripMenuItem.Size = new System.Drawing.Size(79, 20);
            this.trợGiúpToolStripMenuItem.Text = "Trợ giúp";
            // 
            // mTacGia
            // 
            this.mTacGia.Name = "mTacGia";
            this.mTacGia.Size = new System.Drawing.Size(127, 22);
            this.mTacGia.Text = "Tác giả";
            this.mTacGia.Click += new System.EventHandler(this.mTacGia_Click);
            // 
            // mUpdate
            // 
            this.mUpdate.Name = "mUpdate";
            this.mUpdate.Size = new System.Drawing.Size(127, 22);
            this.mUpdate.Text = "Phiên bản";
            this.mUpdate.Click += new System.EventHandler(this.mUpdate_Click);
            // 
            // mNhanVien
            // 
            this.mNhanVien.Name = "mNhanVien";
            this.mNhanVien.Size = new System.Drawing.Size(170, 22);
            this.mNhanVien.Text = "Quản lý nhân viên";
            this.mNhanVien.Click += new System.EventHandler(this.mNhanVien_Click);
            // 
            // goiMon
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(672, 380);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.thongTinBan);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "goiMon";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý cà phê";
            this.Load += new System.EventHandler(this.goiMon_Load);
            this.thongTinBan.ResumeLayout(false);
            this.thongTinBan.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox thongTinBan;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Button btnBan6;
        private System.Windows.Forms.Button btnBan3;
        private System.Windows.Forms.Button btnBan5;
        private System.Windows.Forms.Button btnBan2;
        private System.Windows.Forms.Button btnBan4;
        private System.Windows.Forms.Button btnBan1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mDanhMuc;
        private System.Windows.Forms.ToolStripMenuItem mBan;
        private System.Windows.Forms.ToolStripMenuItem mThucDon;
        private System.Windows.Forms.ToolStripMenuItem mHoaDon;
        private System.Windows.Forms.ToolStripMenuItem mThoat;
        private System.Windows.Forms.ToolStripMenuItem trợGiúpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mTacGia;
        private System.Windows.Forms.ToolStripMenuItem mUpdate;
        private System.Windows.Forms.ToolStripMenuItem mNhanVien;
    }
}