﻿namespace qlcf
{
    partial class quanLyThucDon
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(quanLyThucDon));
            this.danhSachThucDon = new System.Windows.Forms.GroupBox();
            this.lbTong = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.dataThucDon = new System.Windows.Forms.DataGridView();
            this.mathucdon = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tenDoUong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.donGia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.lbTim = new System.Windows.Forms.Label();
            this.btnLai = new System.Windows.Forms.Button();
            this.btnTim = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.textTimKiem = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.themThucDon = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.xoaThucDon = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.btnNhapLai = new System.Windows.Forms.Button();
            this.textDonGia = new System.Windows.Forms.TextBox();
            this.suaThucDon = new System.Windows.Forms.Button();
            this.textTenDoUong = new System.Windows.Forms.TextBox();
            this.textMaDoUong = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.danhSachThucDon.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataThucDon)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // danhSachThucDon
            // 
            this.danhSachThucDon.Controls.Add(this.lbTong);
            this.danhSachThucDon.Controls.Add(this.label6);
            this.danhSachThucDon.Controls.Add(this.dataThucDon);
            this.danhSachThucDon.ForeColor = System.Drawing.Color.Black;
            this.danhSachThucDon.Location = new System.Drawing.Point(24, 73);
            this.danhSachThucDon.Name = "danhSachThucDon";
            this.danhSachThucDon.Size = new System.Drawing.Size(368, 333);
            this.danhSachThucDon.TabIndex = 17;
            this.danhSachThucDon.TabStop = false;
            this.danhSachThucDon.Text = "Thông tin";
            // 
            // lbTong
            // 
            this.lbTong.AutoSize = true;
            this.lbTong.Location = new System.Drawing.Point(137, 303);
            this.lbTong.Name = "lbTong";
            this.lbTong.Size = new System.Drawing.Size(10, 13);
            this.lbTong.TabIndex = 16;
            this.lbTong.Text = ".";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(36, 303);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(95, 13);
            this.label6.TabIndex = 15;
            this.label6.Text = "Tổng số thực đơn:";
            // 
            // dataThucDon
            // 
            this.dataThucDon.AllowUserToAddRows = false;
            this.dataThucDon.AllowUserToDeleteRows = false;
            this.dataThucDon.AllowUserToResizeColumns = false;
            this.dataThucDon.AllowUserToResizeRows = false;
            this.dataThucDon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataThucDon.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.mathucdon,
            this.tenDoUong,
            this.donGia});
            this.dataThucDon.Location = new System.Drawing.Point(30, 19);
            this.dataThucDon.Name = "dataThucDon";
            this.dataThucDon.ReadOnly = true;
            this.dataThucDon.RowHeadersVisible = false;
            this.dataThucDon.Size = new System.Drawing.Size(304, 271);
            this.dataThucDon.TabIndex = 0;
            this.dataThucDon.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataThucDon_RowEnter);
            // 
            // mathucdon
            // 
            this.mathucdon.DataPropertyName = "douongid";
            this.mathucdon.HeaderText = "Mã đồ uống";
            this.mathucdon.Name = "mathucdon";
            this.mathucdon.ReadOnly = true;
            // 
            // tenDoUong
            // 
            this.tenDoUong.DataPropertyName = "tendouong";
            this.tenDoUong.HeaderText = "Tên đồ uống";
            this.tenDoUong.Name = "tenDoUong";
            this.tenDoUong.ReadOnly = true;
            // 
            // donGia
            // 
            this.donGia.DataPropertyName = "dongia";
            dataGridViewCellStyle1.NullValue = null;
            this.donGia.DefaultCellStyle = dataGridViewCellStyle1;
            this.donGia.HeaderText = "Đơn giá";
            this.donGia.Name = "donGia";
            this.donGia.ReadOnly = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.lbTim);
            this.groupBox3.Controls.Add(this.btnLai);
            this.groupBox3.Controls.Add(this.btnTim);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.textTimKiem);
            this.groupBox3.Location = new System.Drawing.Point(439, 323);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(337, 84);
            this.groupBox3.TabIndex = 14;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Tìm kiếm";
            // 
            // lbTim
            // 
            this.lbTim.AutoSize = true;
            this.lbTim.ForeColor = System.Drawing.Color.Red;
            this.lbTim.Location = new System.Drawing.Point(80, 53);
            this.lbTim.Name = "lbTim";
            this.lbTim.Size = new System.Drawing.Size(13, 13);
            this.lbTim.TabIndex = 14;
            this.lbTim.Text = "  ";
            // 
            // btnLai
            // 
            this.btnLai.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(139)))), ((int)(((byte)(215)))));
            this.btnLai.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(129)))), ((int)(((byte)(194)))));
            this.btnLai.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLai.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLai.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnLai.Location = new System.Drawing.Point(235, 48);
            this.btnLai.Name = "btnLai";
            this.btnLai.Size = new System.Drawing.Size(75, 23);
            this.btnLai.TabIndex = 13;
            this.btnLai.Text = "Trở lại";
            this.btnLai.UseVisualStyleBackColor = false;
            this.btnLai.Click += new System.EventHandler(this.btnLai_Click);
            // 
            // btnTim
            // 
            this.btnTim.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(139)))), ((int)(((byte)(215)))));
            this.btnTim.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(129)))), ((int)(((byte)(194)))));
            this.btnTim.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTim.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnTim.Location = new System.Drawing.Point(235, 19);
            this.btnTim.Name = "btnTim";
            this.btnTim.Size = new System.Drawing.Size(75, 23);
            this.btnTim.TabIndex = 13;
            this.btnTim.Text = "Tìm";
            this.btnTim.UseVisualStyleBackColor = false;
            this.btnTim.Click += new System.EventHandler(this.btnTim_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(28, 24);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "Tìm kiếm";
            // 
            // textTimKiem
            // 
            this.textTimKiem.Location = new System.Drawing.Point(83, 21);
            this.textTimKiem.Name = "textTimKiem";
            this.textTimKiem.Size = new System.Drawing.Size(137, 20);
            this.textTimKiem.TabIndex = 11;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.pictureBox1);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.themThucDon);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.xoaThucDon);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.btnNhapLai);
            this.groupBox2.Controls.Add(this.textDonGia);
            this.groupBox2.Controls.Add(this.suaThucDon);
            this.groupBox2.Controls.Add(this.textTenDoUong);
            this.groupBox2.Controls.Add(this.textMaDoUong);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(439, 40);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(337, 260);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Quản lý";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::qlcf.Properties.Resources.icon_thucdon_cafe;
            this.pictureBox1.Location = new System.Drawing.Point(31, 180);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(76, 64);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(25, 132);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Đơn giá";
            // 
            // themThucDon
            // 
            this.themThucDon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(139)))), ((int)(((byte)(215)))));
            this.themThucDon.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(129)))), ((int)(((byte)(194)))));
            this.themThucDon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.themThucDon.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.themThucDon.Location = new System.Drawing.Point(145, 180);
            this.themThucDon.Name = "themThucDon";
            this.themThucDon.Size = new System.Drawing.Size(75, 23);
            this.themThucDon.TabIndex = 10;
            this.themThucDon.Text = "Thêm";
            this.themThucDon.UseVisualStyleBackColor = false;
            this.themThucDon.Click += new System.EventHandler(this.themThucDon_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(25, 92);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Tên đồ uống";
            // 
            // xoaThucDon
            // 
            this.xoaThucDon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(139)))), ((int)(((byte)(215)))));
            this.xoaThucDon.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(129)))), ((int)(((byte)(194)))));
            this.xoaThucDon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.xoaThucDon.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.xoaThucDon.Location = new System.Drawing.Point(235, 221);
            this.xoaThucDon.Name = "xoaThucDon";
            this.xoaThucDon.Size = new System.Drawing.Size(75, 23);
            this.xoaThucDon.TabIndex = 1;
            this.xoaThucDon.Text = "Xóa";
            this.xoaThucDon.UseVisualStyleBackColor = false;
            this.xoaThucDon.Click += new System.EventHandler(this.xoaThucDon_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(25, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Mã đồ uống";
            // 
            // btnNhapLai
            // 
            this.btnNhapLai.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(139)))), ((int)(((byte)(215)))));
            this.btnNhapLai.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(129)))), ((int)(((byte)(194)))));
            this.btnNhapLai.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNhapLai.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnNhapLai.Location = new System.Drawing.Point(145, 221);
            this.btnNhapLai.Name = "btnNhapLai";
            this.btnNhapLai.Size = new System.Drawing.Size(75, 23);
            this.btnNhapLai.TabIndex = 1;
            this.btnNhapLai.Text = "Nhập lại";
            this.btnNhapLai.UseVisualStyleBackColor = false;
            this.btnNhapLai.Click += new System.EventHandler(this.btnNhapLai_Click);
            // 
            // textDonGia
            // 
            this.textDonGia.Location = new System.Drawing.Point(111, 129);
            this.textDonGia.Name = "textDonGia";
            this.textDonGia.Size = new System.Drawing.Size(199, 20);
            this.textDonGia.TabIndex = 5;
            // 
            // suaThucDon
            // 
            this.suaThucDon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(139)))), ((int)(((byte)(215)))));
            this.suaThucDon.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(129)))), ((int)(((byte)(194)))));
            this.suaThucDon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.suaThucDon.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.suaThucDon.Location = new System.Drawing.Point(235, 180);
            this.suaThucDon.Name = "suaThucDon";
            this.suaThucDon.Size = new System.Drawing.Size(75, 23);
            this.suaThucDon.TabIndex = 1;
            this.suaThucDon.Text = "Sửa";
            this.suaThucDon.UseVisualStyleBackColor = false;
            this.suaThucDon.Click += new System.EventHandler(this.suaThucDon_Click);
            // 
            // textTenDoUong
            // 
            this.textTenDoUong.Location = new System.Drawing.Point(111, 85);
            this.textTenDoUong.Name = "textTenDoUong";
            this.textTenDoUong.Size = new System.Drawing.Size(199, 20);
            this.textTenDoUong.TabIndex = 4;
            // 
            // textMaDoUong
            // 
            this.textMaDoUong.BackColor = System.Drawing.SystemColors.Window;
            this.textMaDoUong.Location = new System.Drawing.Point(111, 39);
            this.textMaDoUong.Name = "textMaDoUong";
            this.textMaDoUong.Size = new System.Drawing.Size(199, 20);
            this.textMaDoUong.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Maroon;
            this.label1.Location = new System.Drawing.Point(81, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(222, 25);
            this.label1.TabIndex = 2;
            this.label1.Text = "Danh sách thực đơn";
            // 
            // quanLyThucDon
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(833, 436);
            this.Controls.Add(this.danhSachThucDon);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "quanLyThucDon";
            this.Text = "Quản lý cà phê";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.danhSachThucDon.ResumeLayout(false);
            this.danhSachThucDon.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataThucDon)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView dataThucDon;
        private System.Windows.Forms.Button xoaThucDon;
        private System.Windows.Forms.Button btnNhapLai;
        private System.Windows.Forms.Button suaThucDon;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textDonGia;
        private System.Windows.Forms.TextBox textTenDoUong;
        private System.Windows.Forms.TextBox textMaDoUong;
        private System.Windows.Forms.Button themThucDon;
        private System.Windows.Forms.DataGridViewTextBoxColumn mathucdon;
        private System.Windows.Forms.DataGridViewTextBoxColumn tenDoUong;
        private System.Windows.Forms.DataGridViewTextBoxColumn donGia;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnLai;
        private System.Windows.Forms.Button btnTim;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textTimKiem;
        private System.Windows.Forms.Label lbTim;
        private System.Windows.Forms.Label lbTong;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox danhSachThucDon;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

